<?php
  ob_start();
  include('../_func/co_DBController.php');
  $db_handle = new DBController();

  $custom_query = "SELECT `uacs_acc_code_new` AS ACCOUNT_CODE, 
                          `uacs_acc_title` AS NATURE_OF_COLLECTION,
                          `cr_ir_amount` AS AMOUNT

                          FROM `t_cr_register_income_references` AS CRIR2
                          INNER JOIN `r_uacs` AS UACS
                          ON CRIR2.cr_ir_uac_ID_ref = UACS.uacs_ID
                          GROUP BY CRIR2.cr_ir_uac_ID_ref
                                                                            
                    
                       

  ";
  $spacer = "SELECT NULL AS ACCOUNT_CODE, NULL AS NATURE_OF_COLLECTION, (SUM(`cr_ir_amount`))  AS AMOUNT 
                          FROM `t_cr_register_income_references` AS CRIR2
                          INNER JOIN `r_uacs` AS UACS
                          ON CRIR2.cr_ir_uac_ID_ref = UACS.uacs_ID
                          GROUP BY CRIR2.cr_ir_uac_ID_ref";


  $custom_query1 = "SELECT `uacs_acc_code_new` AS ACCOUNT_CODE, 
                          `uacs_acc_title` AS NATURE_OF_COLLECTION,
                          `cr_ir_amount` AS AMOUNT
                          
                          FROM `t_cr_register_income_references` AS CRIR2
                          INNER JOIN `r_uacs` AS UACS
                          ON CRIR2.cr_ir_uac_ID_ref = UACS.uacs_ID
                          GROUP BY CRIR2.cr_ir_uac_ID_ref
                                                                            
                    
                       

  ";

   $productResult = $db_handle->runQuery($custom_query);
   //$productResult1 = $db_handle->runQuery($custom_query1);
   $spacer = $db_handle->runQuery($spacer);

  if (isset($_POST["export"])) {

      $filename = "Summary_of_collection.xls";
      header("Content-Type: application/vnd.ms-excel");
      header("Content-Disposition: attachment; filename=\"$filename\"");
      $isPrintHeader = false;
      if (! empty($productResult)) {
          foreach ($productResult as $row) {
              if (! $isPrintHeader) {
                  echo implode("\t", array_keys($row)) . "\n";
                  $isPrintHeader = true;
              }
              echo implode("\t", array_values($row)) . "\n";
          }
      }
      if (! empty($spacer)) {
          foreach ($spacer as $row1) {
              if (! $isPrintHeader) {
                  echo implode("\t", array_keys($row1)) . "\n";
                  $isPrintHeader = true;
              }
              echo implode("\t", array_values($row1)) . "\n";
          }
      }
      
      exit();
  }
  ob_flush();
?>